<tr><td><a href="product_info.php?products_id=92"><img src="<?=DIR_WS_TEMPLATES . TEMPLATE_NAME?>/images/x4.jpg" width="180" height="101" border="0" style="margin:2px 0 2px 0;"></a></td></tr>
