<script language="javascript"><!--
function session_win() {
  window.open("<?php echo tep_href_link(DIR_WS_TEMPLATES . TEMPLATE_NAME . '/content/' . FILENAME_INFO_SHOPPING_CART); ?>","info_shopping_cart","height=460,width=430,toolbar=no,statusbar=no,scrollbars=yes").focus();
}
//--></script>
