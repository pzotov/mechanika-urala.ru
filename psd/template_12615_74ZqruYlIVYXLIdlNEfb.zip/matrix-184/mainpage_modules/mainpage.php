<?php
/*
  $Id: mainpage.php,v 2.0 2003/06/13

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
?>
<!-- default_specials //-->


<?php



include(DIR_WS_LANGUAGES . $language . '/' . FILENAME_DEFINE_MAINPAGE);




?>

<!-- default_specials_eof //-->
