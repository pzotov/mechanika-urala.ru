<tr><td><a href="product_info.php?products_id=81"><img src="<?=DIR_WS_TEMPLATES . TEMPLATE_NAME?>/images/x5.jpg" width="180" height="93" border="0"></a></td></tr>
