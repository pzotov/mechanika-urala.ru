<tr><td ><a href=<?=tep_href_link('index.php', 'cPath=26')?>><img src="<?=DIR_WS_TEMPLATES . TEMPLATE_NAME?>/images/x3.jpg" width="180" height="129" border="0" style="margin-top:2px;"></a></td></tr>
